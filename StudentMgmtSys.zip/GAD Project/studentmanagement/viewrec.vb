﻿Imports System.Data.OleDb

Public Class viewrec

    Private Sub viewrec_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'StuddbDataSet.Studdetails' table. You can move, or remove it, as needed.
        'Me.StuddetailsTableAdapter.Fill(Me.StuddbDataSet.Studdetails)

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub DataGridView1_CellContentClick_1(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

        Dim ctr As New OleDbConnection
        cn = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=E:\db - Copy\studdb.accdb")
        cn.Open()
        Dim str = "Select DISTINCT * from Studdetails"
        Dim adp As OleDbDataAdapter = New OleDbDataAdapter(str, cn)
        Dim ds As DataSet = New DataSet
        adp.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim ctr As New OleDbConnection
        cn = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=E:\db - Copy\studdb.accdb")
        cn.Open()
        Dim str = "Select DISTINCT * from Studdetails"
        Dim adp As OleDbDataAdapter = New OleDbDataAdapter(str, cn)
        Dim ds As DataSet = New DataSet
        adp.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
    End Sub
End Class